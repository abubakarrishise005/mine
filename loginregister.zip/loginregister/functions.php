<?php
include 'conn.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f_name = $_POST['f_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $password = $_POST['password'];
    $c_password = $_POST['c_password'];

  

    $insert_query = "INSERT INTO `login` (`f_name`, `last_name`, `email`, `gender`, `password`, `c_password`) VALUES ('$f_name', '$last_name', '$email', '$gender', '$password', '$c_password')";
    $result = mysqli_query($conn, $insert_query);
    if ($result) {
      echo "Registered Successfully";
    } 
    else {
        echo "Error inserting record: " . mysqli_error($conn);
    }
}







