$("#registerForm").on('click','#submit',function (event) {
  event.preventDefault();
  var data = $("#registerForm").serialize();
  $.ajax({
      type: "POST",
      url: "register.php",
      data: $(this).serialize(),
      data: data,
    success: function (data) {
      if(data === "success")
      {
        window.location.href = "login.php";
      }
    },

  });
});
