<?php include 'functions.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
  <script src="sweetalert2.all.min.js"></script>
  <title>Document</title>
</head>
<body>
  <div class="container">
    <h2>Register</h2>
    <div id="success-message" style="display: none;"></div>
    <form id="registerForm" method="post" action="">
    <div>
      <div class="form-group">
        <label for="f_name">First Name:</label>
        <input type="text" id="f_name" name="f_name" class="form-control" >
      </div>
      <div class="form-group">
        <label for="last_name">Last Name:</label>
        <input type="text" id="last_name" name="last_name" class="form-control" >
      </div>
      <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" class="form-control" >
      </div>
      <div class="form-group">
        <label for="gender">Gender:</label><br>
        <input type="radio" name="gender" 
        <?php if (isset($gender) && $gender=="female") echo "checked";?>
        value="female">Female
        <input type="radio" name="gender" 
        <?php if (isset($gender) && $gender=="male") echo "checked";?>
        value="male">Male 
      </div>
      <div class="form-group">
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" class="form-control" >
      </div>
      <div class="form-group">
        <label for="c_password">Confirm Password:</label>
        <input type="password" id="c_password" name="c_password" class="form-control" >
      </div>
      <button type="submit" id="submit" class="btn btn-primary">Register</button>
      <a href="login.php" type="submit"  class="btn btn-primary">Login</a>
    </form>
    <p id="successMessage" class="text-center mt-3"></p>
    <p id="errorMessage" class="text-center mt-3"></p>
  </div>
  <script src="js/function.js"></script>
</body>
</html>
