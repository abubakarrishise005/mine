$(document).ready(function() {
  $("#registerForm").on("submit", function (e) {
    e.preventDefault();
    var data = $("#registerForm").serialize();
    $.ajax({
      type: "POST",
      url: "functions.php",
      data: data,
      success: function (response) {
        var data= JSON.parse(response);
        if (data.email) {
          $("#successMessage").html("Registered Successfully !").css("color", "red");
        }else (data.already)
        {
          $("#errorMessage").html("Email already taken.").css("color", "red");
        }
      }
    });  
  });
});
// handling errors///
$(document).ready(function(){
  //  $("#registerForm").on("submit",function (){
   
  //   var msg = $("#f_name").val();
  //   if(msg === "")
  //   {
  //    $("#f_name").after("<small class = 'text-danger'> * Field is required</small>");
  //   }
  //  })
   
})

$(document).ready(function() {
  $("#loginForm").on("submit", function () {
    var data = $("#loginForm").serialize();
    $.ajax({
      type: "POST",
      url: "loginfunction.php",
      data: data,
      success: function (data) {
        if (data === "Login Successful") {
          window.location.href = 'http://localhost/loginregister/welcome.php';
          $("#loginMessage").html("Login Successful").css("color", "green");
        } else {
          $("#loginMessage").html("Login Failed").css("color", "red");
        }
      }
    });  
  });
});
