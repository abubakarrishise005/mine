<?php
include 'conn.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $array = [];
  $f_name = trim($_POST['f_name']);
  $last_name = trim($_POST['last_name']);
  $email = trim($_POST['email']);
  $gender = $_POST['gender'];
  $password = $_POST['password'];
  $c_password = $_POST['c_password'];

  if (empty($f_name)) {
    $array['f_name'] = "Name  cannot be blank";
  }
  if (empty($last_name)) {
    $array['last_name'] = "Last name cannot be blank";
  }
  if (empty($email)) {
    $array['email'] = "Email cannot be blank";
  }
  if (empty($array)) {
    $email_check_query = "SELECT * FROM login WHERE email = '$email'";
    $result = mysqli_query($conn, $email_check_query);
    if (mysqli_num_rows($result) > 0) {
        $array['already'] = "Email already taken.";
    }

    if ($password !== $c_password) {
      $array['password'] = "Passwords do not match.";
    }

    $password = password_hash($password, PASSWORD_DEFAULT);

    $insert_query = "INSERT INTO `login` (`f_name`, `last_name`, `email`, `gender`, `password`) VALUES ('$f_name', '$last_name', '$email', '$gender', '$password')";
    $result = mysqli_query($conn, $insert_query);
    if ($result) {
        $array['success'] = "Registered Successfully";
    } else {
      $array['not_registered'] = "Error inserting record: " . mysqli_error($conn);
    }
  }
  echo json_encode($array);
}

?>
